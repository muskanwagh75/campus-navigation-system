import raw from '../data/campus.mock.json' with {type:'json'};
import {AppError} from '../utils/errors.js';
function validateDataset(data){
  if(data.isMock!==true)throw new AppError('INTERNAL_ERROR',500,'Campus dataset must declare isMock=true');
  const ids=new Set(data.nodes.map(n=>n.id));
  if(ids.size!==data.nodes.length)throw new AppError('INTERNAL_ERROR',500,'Campus dataset contains duplicate node IDs');
  for(const node of data.nodes)if(!/^[a-z0-9]+(?:_[a-z0-9]+)*$/.test(node.id))throw new AppError('INTERNAL_ERROR',500,`Invalid campus node ID: ${node.id}`);
  const seen=new Set([data.nodes[0]?.id]);
  const queue=[data.nodes[0]?.id];
  const adjacency=Object.fromEntries(data.nodes.map(n=>[n.id,[]]));
  for(const edge of data.edges){const [from,to,distance]=edge;if(!ids.has(from)||!ids.has(to)||!(distance>0))throw new AppError('INTERNAL_ERROR',500,`Invalid campus edge: ${from} -> ${to}`);adjacency[from].push(to);adjacency[to].push(from);}
  while(queue.length){for(const next of adjacency[queue.shift()])if(!seen.has(next)){seen.add(next);queue.push(next);}}
  if(seen.size!==ids.size)throw new AppError('INTERNAL_ERROR',500,'Campus graph is disconnected');
}
export function createCampusService(data=raw){
  validateDataset(data);
  const nodes=data.nodes.map(n=>({...n,aliases:n.aliases||[],kind:n.kind||n.type,node:n.node||n.id}));
  const nodesById=Object.fromEntries(nodes.map(n=>[n.id,n]));
  const edges=data.edges.map((edge,i)=>Array.isArray(edge)?{from:edge[0],to:edge[1],distance:edge[2],accessible:edge[3]!==false,blocked:false,type:'walkway',hint:'Continue along the path',oneWay:false,id:`edge_${i}`}:{...edge});
  const places=nodes.map(n=>({...n}));
  const buildings=[...new Map(places.filter(p=>p.type==='Building'||p.building).map(p=>[p.building,{id:p.building.toLowerCase().replace(/\s+/g,'_'),name:p.building}])).values()];
  const services=[{keywords:['fee','fees','pay fees','receipt','accounts'],place:'accounts_office'},{keywords:['exam','hall ticket','exam form'],place:'exam_cell'},{keywords:['bonafide','certificate'],place:'admin_block'},{keywords:['library','books','study'],place:'library'}];
  const graph={meta:{isMock:Boolean(data.isMock),campusName:data.campusName||'Prototype campus'},nodes,edges,places,buildings,services};
  return {raw:data,graph,nodes,nodesById,edges,places,buildings,services,stats:{places:places.length,nodes:nodes.length,edges:edges.length}};
}
