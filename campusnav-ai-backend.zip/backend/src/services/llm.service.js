import {env} from '../config/env.js';
export async function resolveWithLLM(){if(!env.LLM_ENABLED||!env.LLM_API_KEY)return null;return null;}
