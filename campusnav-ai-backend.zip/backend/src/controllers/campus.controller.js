import {ok} from '../utils/response.js';export const getCampus=(req,res)=>ok(res,{campus:req.app.locals.services.campus.graph});
