export function notFound(req,res){res.status(404).json({success:false,error:{code:'NOT_FOUND',message:`Route not found: ${req.method} ${req.path}`}});}
export function errorHandler(err,req,res,next){const status=err.status||500;res.status(status).json({success:false,error:{code:err.code||'INTERNAL_ERROR',message:status===500?'Internal server error':err.message,details:err.details||undefined}});}
