import {Router} from 'express';import {createRoute} from '../controllers/navigation.controller.js';const router=Router();router.post('/',createRoute);export default router;
