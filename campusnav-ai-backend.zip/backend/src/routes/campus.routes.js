import {Router} from 'express';import {getCampus} from '../controllers/campus.controller.js';const router=Router();router.get('/',getCampus);export default router;
