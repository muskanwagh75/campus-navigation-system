import {Router} from 'express';import {queryAssistant} from '../controllers/assistant.controller.js';const router=Router();router.post('/query',queryAssistant);export default router;
