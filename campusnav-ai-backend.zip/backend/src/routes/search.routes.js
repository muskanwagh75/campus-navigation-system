import {Router} from 'express';import {searchLocations} from '../controllers/search.controller.js';const router=Router();router.get('/',searchLocations);export default router;
