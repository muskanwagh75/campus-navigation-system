export class AppError extends Error{constructor(code,status,message,details=null){super(message);this.name='AppError';this.code=code;this.status=status;this.details=details;}}
export const invalid=(message,details)=>new AppError('INVALID_REQUEST',400,message,details);
