export function normalizeText(value=''){return String(value).toLowerCase().normalize('NFKD').replace(/[^\w\s-]/g,' ').replace(/\s+/g,' ').trim();}
export function tokenize(value=''){return normalizeText(value).split(' ').filter(Boolean);}
