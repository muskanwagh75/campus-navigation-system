import {AppError} from './errors.js';
export function requireString(value,name){if(typeof value!=='string'||!value.trim())throw new AppError('INVALID_REQUEST',400,`${name} must be a non-empty string`);return value.trim();}
export function requireBoolean(value,name){if(value!==undefined&&typeof value!=='boolean')throw new AppError('INVALID_REQUEST',400,`${name} must be boolean`);return value??false;}
export function assertKnownLocation(id,campus){if(!campus.nodesById[id])throw new AppError('LOCATION_NOT_FOUND',404,`Unknown location: ${id}`,{id});}
