import raw from '../src/data/campus.mock.json' with {type:'json'};

const ids = new Set(raw.nodes.map(node => node.id));
const errors = [];
if (raw.isMock !== true) errors.push('isMock must be true');
if (ids.size !== raw.nodes.length) errors.push('node IDs must be unique');
for (const node of raw.nodes) {
  if (!/^[a-z0-9]+(?:_[a-z0-9]+)*$/.test(node.id)) errors.push(`invalid snake_case ID: ${node.id}`);
}
for (const [from, to, distance] of raw.edges) {
  if (!ids.has(from) || !ids.has(to)) errors.push(`edge endpoint missing: ${from} -> ${to}`);
  if (!(distance > 0)) errors.push(`edge distance must be positive: ${from} -> ${to}`);
}
if (errors.length) {
  console.error(`Campus data validation failed:\n- ${errors.join('\n- ')}`);
  process.exit(1);
}
console.log(`Campus data valid: ${raw.nodes.length} nodes, ${raw.edges.length} edges, isMock=${raw.isMock}`);
