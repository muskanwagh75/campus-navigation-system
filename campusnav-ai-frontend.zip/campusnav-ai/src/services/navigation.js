export function createNavigation(data) {
  const nodes = Object.fromEntries(data.nodes.map(node => [node.id, node]));
  const graph = Object.fromEntries(data.nodes.map(node => [node.id, []]));
  data.edges.forEach(([from, to, distance, accessible]) => {
    graph[from].push({to, distance, accessible}); graph[to].push({to: from, distance, accessible});
  });
  function findRoute(startId, destinationId, options = {}) {
    if (!nodes[startId] || !nodes[destinationId]) return null;
    const distances = Object.fromEntries(Object.keys(graph).map(id => [id, Infinity]));
    const previous = {}; const open = new Set(Object.keys(graph)); distances[startId] = 0;
    while (open.size) {
      const current = [...open].reduce((best, id) => distances[id] < distances[best] ? id : best);
      open.delete(current); if (current === destinationId) break;
      graph[current].forEach(edge => {
        if (options.accessible && !edge.accessible) return;
        const next = distances[current] + edge.distance;
        if (next < distances[edge.to]) { distances[edge.to] = next; previous[edge.to] = current; }
      });
    }
    if (distances[destinationId] === Infinity) return null;
    const path = []; let cursor = destinationId;
    while (cursor) { path.unshift(cursor); cursor = previous[cursor]; }
    const directions = path.slice(1).map((id, index) => {
      const prev = nodes[path[index]]; const next = nodes[id];
      return index === 0 ? `Start at ${prev.name}` : `Continue toward ${next.name}`;
    });
    directions.push(`${nodes[destinationId].name} is on your ${destinationId.includes('lab') ? 'left' : 'right'}`);
    const floors = new Set(path.map(id => nodes[id].floor)).size;
    return {nodes: path, distance: Math.round(distances[destinationId]), duration: Math.max(1, Math.ceil(distances[destinationId] / 78)), floors, directions};
  }
  return {nodes, graph, findRoute};
}
