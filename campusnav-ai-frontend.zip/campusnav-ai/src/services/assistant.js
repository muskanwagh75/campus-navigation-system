const intents = [
  {terms:['fee','fees','pay','receipt','accounts'], id:'accounts_office', label:'fee-related services'},
  {terms:['exam','hall ticket','hall-ticket','form'], id:'exam_cell', label:'exam forms and hall-ticket help'},
  {terms:['bonafide','certificate','admin'], id:'admin_block', label:'administrative support'},
  {terms:['library','books','study'], id:'library', label:'quiet study and reference'},
  {terms:['cse lab 2','lab 2'], id:'cse_lab_2', label:'CSE Lab 2'},
  {terms:['cse','computer science'], id:'cse_department', label:'CSE department'}
];
export function resolveAssistant(input, nodes) {
  const query = input.toLowerCase();
  const match = intents.find(intent => intent.terms.some(term => query.includes(term)));
  if (match) return {type:'action', location:nodes[match.id], message:`I’d point you to ${nodes[match.id].name} for ${match.label}.`};
  const suggestions = Object.values(nodes).filter(node => query.split(/\s+/).some(word => word.length > 2 && node.name.toLowerCase().includes(word))).slice(0,3);
  return {type:'unknown', suggestions, message:'I’m not sure which prototype campus location you mean yet.'};
}
