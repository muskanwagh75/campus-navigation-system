const initialState = {
  view: 'map', start: 'main_gate', destination: null, route: null, accessible: false,
  selectedLocation: null, assistantOpen: false, chatHistory: [], navigationStep: 0,
  lostMode: false, lostStart: 'main_gate', zoom: 1
};
let state = {...initialState};
const listeners = new Set();
export const getState = () => state;
export function setState(patch) { state = {...state, ...(typeof patch === 'function' ? patch(state) : patch)}; listeners.forEach(fn => fn(state)); }
export function subscribe(fn) { listeners.add(fn); return () => listeners.delete(fn); }
export function resetState() { state = {...initialState}; listeners.forEach(fn => fn(state)); }
